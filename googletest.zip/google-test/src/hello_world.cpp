#include <iostream>
#include <string>
#include "hello_world.h"



  ///////////////////////////////////////
  //// In the class implementation file

string Salutation::greet(const string& name) {
//	ostringstream s;
//	s << "Hello " << name << "!";
 //	return s.str();
	return "Hello " + name;
}
  

