#include <iostream>
#include <string>

using namespace std;

class Salutation
{
public:
	static string greet(const string& name);
};
