#include "gtest/gtest.h"
#include "../src/hello_world.h"

using namespace std;

TEST(SalutationTest, Static) {
	EXPECT_EQ(string("Hello World"), Salutation::greet("World"));
}
